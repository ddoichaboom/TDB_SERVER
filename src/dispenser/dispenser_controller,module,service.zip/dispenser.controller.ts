import {
  Body,
  Controller,
  Get,
  InternalServerErrorException,
  Logger,
  Param,
  Post,
} from '@nestjs/common';
import { DispenserService } from './dispenser.service';

@Controller('dispenser')
export class DispenserController {
  private readonly logger = new Logger(DispenserController.name);

  constructor(private readonly dispenserService: DispenserService) {}

  @Post('verify-uid')
  async verifyUid(@Body() body: { uid: string }) {
    return await this.dispenserService.authenticateByUid(body.uid);
  }

  @Post('confirm')
  async confirmIntake(@Body() body: { uid: string }) {
    return await this.dispenserService.confirmIntake(body.uid);
  }

  @Get('medicine/:connect')
  async getMedicineList(@Param('connect') connect: string) {
    try {
      return await this.dispenserService.getMedicineListByConnect(connect);
    } catch (error: unknown) {
      const err = error as Error;
      this.logger.error(`getMedicineList error: ${err.message}`, err.stack);
      throw new InternalServerErrorException('약 정보 조회 중 오류 발생');
    }
  }

  @Get('schedules/connect/:connect')
  async getTodaySchedulesByConnect(@Param('connect') connect: string) {
    try {
      return await this.dispenserService.getTodayScheduleByConnect(connect);
    } catch (error: unknown) {
      const err = error as Error;
      this.logger.error(
        `getTodaySchedulesByConnect error: ${err.message}`,
        err.stack,
      );
      throw new InternalServerErrorException('스케줄 조회 중 오류 발생');
    }
  }

  @Get('schedules/user/:user_id')
  async getTodaySchedulesByUser(@Param('user_id') user_id: string) {
    try {
      return await this.dispenserService.getTodayScheduleByUser(user_id);
    } catch (error: unknown) {
      const err = error as Error;
      this.logger.error(
        `getTodaySchedulesByUser error: ${err.message}`,
        err.stack,
      );
      throw new InternalServerErrorException('스케줄 조회 중 오류 발생');
    }
  }

  @Post('dispense-list')
  async getDispenseList(@Body() body: { k_uid: string }) {
    try {
      return await this.dispenserService.getDispenseListByKitUid(body.k_uid);
    } catch (error: unknown) {
      const err = error as Error;
      this.logger.error(`getDispenseList error: ${err.message}`, err.stack);
      throw new InternalServerErrorException('배출 목록 조회 중 오류 발생');
    }
  }

  @Post('dispense-result')
  async reportDispenseResult(
    @Body()
    body: {
      k_uid: string;
      dispenseList: { medi_id: string; dose: number }[];
    },
  ) {
    try {
      return await this.dispenserService.handleDispenseResult(
        body.k_uid,
        body.dispenseList,
      );
    } catch (error: unknown) {
      const err = error as Error;
      this.logger.error(
        `reportDispenseResult error: ${err.message}`,
        err.stack,
      );
      throw new InternalServerErrorException('배출 처리 중 오류 발생');
    }
  }
}
