import {
  Injectable,
  NotFoundException,
  InternalServerErrorException,
  Logger,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, In } from 'typeorm';
import { User } from './entities/user.entity';
import { Cron } from '@nestjs/schedule';
import { Schedule, DayOfWeek, TimeOfDay } from './entities/schedule.entity';
import { Medicine } from './entities/medicine.entity';
import { Machine } from './entities/machine.entity';

@Injectable()
export class DispenserService {
  private readonly logger = new Logger(DispenserService.name);

  @Cron('0 0 * * *', { name: 'dailyReset' }) // 매일 자정
  async resetTookToday() {
    this.logger.log('⏰ [CRON] 매일 자정: took_today 초기화 시작');

    try {
      const result = await this.userRepo
        .createQueryBuilder()
        .update()
        .set({ took_today: 0 })
        .execute();

      this.logger.log(`✅ [CRON] 초기화 완료 - ${result.affected}명`);
    } catch (err: unknown) {
      const error = err as Error;
      this.logger.error(`❌ [CRON] 초기화 실패: ${error.message}`);
    }
  }

  constructor(
    @InjectRepository(User)
    private readonly userRepo: Repository<User>,
    @InjectRepository(Schedule)
    private readonly scheduleRepo: Repository<Schedule>,
    @InjectRepository(Medicine)
    private readonly medicineRepo: Repository<Medicine>,
    @InjectRepository(Machine)
    private readonly machineRepo: Repository<Machine>,
  ) {}

  async authenticateByUid(uid: string) {
    this.logger.log(`UID 인증 시도: ${uid}`);

    try {
      const user = await this.userRepo.findOne({ where: { k_uid: uid } });

      if (!user) {
        this.logger.warn(`미등록 UID: ${uid}`);
        const qrPayload = {
          type: 'register',
          k_uid: uid,
          createdAt: new Date().toISOString(),
        };

        return {
          status: 'unregistered',
          qr_data: qrPayload,
        };
      }

      this.logger.log(`등록된 UID: ${uid} → 사용자 ID: ${user.user_id}`);

      return {
        status: 'ok',
        user: {
          user_id: user.user_id,
          name: user.name,
          role: user.role,
        },
      };
    } catch (error: unknown) {
      const err = error as Error;
      this.logger.error(`UID 인증 중 오류: ${err.message}`, err.stack);
      throw new InternalServerErrorException(
        'UID 인증 처리 중 서버 오류가 발생했습니다.',
      );
    }
  }

  async confirmIntake(uid: string) {
    this.logger.log(`💊 약 복용 완료 처리 요청: ${uid}`);

    try {
      const user = await this.userRepo.findOne({ where: { k_uid: uid } });

      if (!user) {
        this.logger.warn(`❌ UID에 해당하는 사용자 없음: ${uid}`);
        throw new NotFoundException('등록되지 않은 사용자입니다.');
      }

      if (user.took_today === 1) {
        this.logger.log(`ℹ️ 이미 오늘 약 복용 완료 처리된 UID: ${uid}`);
        return { status: 'already_confirmed' };
      }

      user.took_today = 1;
      await this.userRepo.save(user);

      this.logger.log(`✅ 복용 상태 업데이트 완료: ${user.user_id}`);
      return { status: 'confirmed', user_id: user.user_id };
    } catch (error: unknown) {
      const err = error as Error;
      this.logger.error(`❌ 복용 처리 중 오류 발생: ${err.message}`);
      throw new InternalServerErrorException(
        '복용 처리 중 오류가 발생했습니다.',
      );
    }
  }

  async getTodayScheduleByConnect(connect: string) {
    this.logger.log(`📅 가족 스케줄 조회 요청 - connect: ${connect}`);

    const today = new Date();
    const dayOfWeek = today
      .toLocaleDateString('en-US', { weekday: 'short' })
      .toLowerCase() as DayOfWeek;

    const hour = today.getHours();
    const timeOfDay: TimeOfDay =
      hour < 12 ? 'morning' : hour < 18 ? 'afternoon' : 'evening';

    const schedule = await this.scheduleRepo.find({
      where: {
        connect,
        day_of_week: dayOfWeek,
        time_of_day: timeOfDay,
      },
      relations: ['medicine'],
    });

    return schedule.map((item) => ({
      schedule_id: item.schedule_id,
      medi_id: item.medi_id,
      medicine_name: item.medicine?.name || '',
      dose: item.dose,
      time_of_day: item.time_of_day,
      user_id: item.user_id,
    }));
  }

  async getTodayScheduleByUser(user_id: string) {
    this.logger.log(`📅 개별 스케줄 조회 요청 - user_id: ${user_id}`);

    const today = new Date();
    const dayOfWeek = today
      .toLocaleDateString('en-US', { weekday: 'short' })
      .toLowerCase() as DayOfWeek;

    const hour = today.getHours();
    const timeOfDay: TimeOfDay =
      hour < 12 ? 'morning' : hour < 18 ? 'afternoon' : 'evening';

    const schedule = await this.scheduleRepo.find({
      where: {
        user_id,
        day_of_week: dayOfWeek,
        time_of_day: timeOfDay,
      },
      relations: ['medicine'],
    });

    return schedule.map((item) => ({
      schedule_id: item.schedule_id,
      medi_id: item.medi_id,
      medicine_name: item.medicine?.name || '',
      dose: item.dose,
      time_of_day: item.time_of_day,
      user_id: item.user_id,
    }));
  }

  async getMedicineListByConnect(connect: string) {
    this.logger.log(`🧾 약 목록 조회 요청 - connect: ${connect}`);

    try {
      const machines = await this.machineRepo.find({
        where: { owner: connect },
        relations: ['medicine'],
      });

      return machines.map((m) => ({
        medi_id: m.medi_id,
        name: m.medicine?.name || '',
        remain: m.remain,
        total: m.total,
        slot: m.slot,
        warning: m.medicine?.warning || 0,
      }));
    } catch (error: unknown) {
      const err = error as Error;
      this.logger.error(`❌ 약 목록 조회 중 오류: ${err.message}`);
      throw new InternalServerErrorException(
        '약 목록 조회 중 오류가 발생했습니다.',
      );
    }
  }

  async getDispenseListByKitUid(k_uid: string) {
    this.logger.log(`🚚 배출 리스트 요청 - k_uid: ${k_uid}`);

    const user = await this.userRepo.findOne({ where: { k_uid } });
    if (!user) {
      this.logger.warn(`❌ 등록되지 않은 UID: ${k_uid}`);
      throw new NotFoundException('등록되지 않은 사용자입니다.');
    }

    const today = new Date();
    const dayOfWeek = today
      .toLocaleDateString('en-US', { weekday: 'short' })
      .toLowerCase() as DayOfWeek;

    const hour = today.getHours();
    let timeSlots: TimeOfDay[];

    if (hour < 12) {
      timeSlots = ['morning', 'afternoon', 'evening'];
    } else if (hour < 18) {
      timeSlots = ['afternoon', 'evening'];
    } else {
      timeSlots = ['evening'];
    }

    const schedules = await this.scheduleRepo.find({
      where: {
        user_id: user.user_id,
        day_of_week: dayOfWeek,
        time_of_day: In(timeSlots),
      },
      relations: ['medicine'],
    });

    return schedules.map((s) => ({
      medi_id: s.medi_id,
      medicine_name: s.medicine?.name || '',
      dose: s.dose,
    }));
  }

  async handleDispenseResult(
    k_uid: string,
    dispenseList: { medi_id: string; dose: number }[],
  ) {
    this.logger.log(`📦 배출 처리 요청 - UID: ${k_uid}`);

    const user = await this.userRepo.findOne({ where: { k_uid } });
    if (!user) throw new NotFoundException('등록되지 않은 사용자입니다.');

    const insufficient: string[] = [];

    for (const item of dispenseList) {
      const machine = await this.machineRepo.findOne({
        where: {
          medi_id: item.medi_id,
          owner: user.connect,
        },
        relations: ['medicine'],
      });

      if (!machine) {
        this.logger.warn(`❌ 존재하지 않는 약: ${item.medi_id}`);
        continue;
      }

      if (machine.remain < item.dose) {
        this.logger.warn(
          `⚠ 잔량 부족 - ${machine.medicineById?.name || machine.medicineByConnect?.name} (${machine.remain} < ${item.dose})`,
        );
        insufficient.push(
          machine.medicineById?.name || machine.medicineByConnect?.name || '',
        );
        continue;
      }

      machine.remain -= item.dose;

      if (machine.remain <= 5) {
        await this.medicineRepo.update(machine.medi_id, { warning: 1 });
      }

      await this.machineRepo.save(machine);
      this.logger.log(
        `✅ ${machine.medicineById?.name || machine.medicineByConnect?.name} 배출 완료 (${item.dose}개 차감)`,
      );
    }

    return {
      status: 'completed',
      insufficient,
    };
  }
}
