import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DispenserModule } from './dispenser/dispenser.module';
import { User } from './dispenser/entities/user.entity';
import { Schedule } from './dispenser/entities/schedule.entity';
import { Medicine } from './dispenser/entities/medicine.entity';
import { Machine } from './dispenser/entities/machine.entity';
import { ScheduleModule } from '@nestjs/schedule';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: 'tdb.cjeqcgui8jse.ap-northeast-2.rds.amazonaws.com', // RDS 엔드포인트
      port: 3306,
      username: 'admin',
      password: 'kdu5525^',
      database: 'tdb',
      entities: [User, Schedule, Medicine, Machine],
      synchronize: false, // ⚠️ 기존 테이블 덮어쓰지 않도록 설정
    }),
    TypeOrmModule.forFeature([User, Schedule, Medicine, Machine]),
    ScheduleModule.forRoot(),
    DispenserModule,
  ],
})
export class AppModule {}
